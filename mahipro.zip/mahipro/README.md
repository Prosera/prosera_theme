
# Mahi Pro
Mahi Pro is a clean, elegant, professional, modern, multipurpose and fully responsive Drupal 9 and 10 Theme.


## THEME FEATURES
- Drupal 9.x, 10.x compatible
- Fully responsive
- Clean & modern design
- HTML5 & CSS3
- Google Font (self hosted and CDN)
- Multi-level drop down main menu
- Google Material Font Icons
- FontAwesome Font Icons
- Bootstrap font icons
- Inbuilt slider for homepage.
- One column, two column, three column page layout.
- Intelligent dynamic columns
- Customizable theme setting
- and more..


## Theme page
https://drupar.com/theme/mahipro


## Theme Demo
https://demo.drupar.com/mahipro/


## Documentaion
https://drupar.com/doc/mahipro


## Demo Content
https://drupar.com/doc/mahipro/demo-site-content


## Custom Shortcodes
https://drupar.com/doc/mahipro/custom-shortcodes


## Block region
https://drupar.com/doc/mahipro/block-regions


## Requirements
Mahi Pro theme does not require anything beyond Drupal 9 /10 core to work.


## Installation
https://drupar.com/doc/mahipro/how-install-mahipro-theme


## Configuration
Navigate to: Administration >> Appearance >> Settings >> mahipro


## maintainer
Current maintainer:
* Ravi Shekhar - https://www.drupal.org/u/ravis